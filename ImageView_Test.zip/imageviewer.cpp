﻿#include "imageviewer.h"
#include "ui_imageviewer.h"
#include <QVBoxLayout>
#include <QDebug>
#include <QTimer>

ImageViewer::ImageViewer(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ImageViewer)
{
    ui->setupUi(this);

    imageLabel = new QLabel(this);
    imageLabel->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
    imageLabel->setScaledContents(true);

    QString folder = "C:/work/src/Qt_VTK_CT/Images/Ceph_Frame(48x2400)";
    imageIterator = new QDirIterator(folder, QDirIterator::Subdirectories);

    imageTimer = new QTimer(this);
    connect(imageTimer, &QTimer::timeout, this, &ImageViewer::showNextImage);
    imageTimer->start(3000);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(imageLabel);
    setLayout(mainLayout);

    showNextImage();

}

ImageViewer::~ImageViewer()
{
    delete ui;
}

QPixmap ImageViewer::PanoImageViewer(QString path)
{
    //QString panoPath = "C:/work/src/Qt_VTK_CT/Images/Ceph_Frame(48x2400)/0002.raw";
    QFile panoFile(path);
    if (!panoFile.open(QFile::ReadOnly))
        return QPixmap();

    QByteArray ba = panoFile.readAll();
    const uchar* data = (const uchar*) ba.constData();;
    panoFile.close();
    //QImage image(data, 30, 30, QImage::Format_RGB32);
    QImage* panoImage = new QImage(data, 150, 470, QImage::Format_RGB555);
    QImage pano_Image(*panoImage);
    QPixmap panoPix;
    panoPix = QPixmap::fromImage(pano_Image,Qt::AutoColor);
    return panoPix;
}

void ImageViewer::showNextImage()
{
    if (imageIterator->hasNext())
    {
        imageIterator->next();

        qDebug() << __FUNCTION__ << imageIterator->filePath();

        QPixmap image = PanoImageViewer(imageIterator->filePath());
        //QPixmap image(imageIterator->filePath());
        imageLabel->setPixmap(image);
        imageLabel->adjustSize();
    }
    else
    {
        //imageIterator->rewind();
    }

}
