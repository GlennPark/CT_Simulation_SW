﻿#ifndef IMAGEVIEWER_H
#define IMAGEVIEWER_H
#include <QLabel>
#include <QWidget>
#include <QDirIterator>

namespace Ui {
class ImageViewer;
}

class ImageViewer : public QWidget
{
    Q_OBJECT

public:
    explicit ImageViewer(QWidget *parent = nullptr);
    ~ImageViewer();

    QPixmap PanoImageViewer(QString path);

private slots:
    void showNextImage();

private:
    Ui::ImageViewer *ui;

private:
    QLabel *imageLabel;
    QDirIterator *imageIterator;
    QTimer *imageTimer;

};

#endif // IMAGEVIEWER_H
